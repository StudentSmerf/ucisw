/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/lab/Desktop/test7/test6/test5/test2/test2/Memory32_32_16.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_2974294041_3212880686_p_0(char *t0)
{
    char t13[16];
    char t26[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t14;
    char *t15;
    int t16;
    unsigned int t17;
    int t18;
    int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t27;
    char *t28;
    int t29;
    unsigned int t30;
    int t31;
    int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;

LAB0:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 1312U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3792);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(89, ng0);
    t3 = (t0 + 1992U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:
LAB6:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 2312U);
    t3 = *((char **)t1);
    t1 = (t0 + 1032U);
    t4 = *((char **)t1);
    t10 = (9 - 4);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t4 + t12);
    t7 = (t13 + 0U);
    t9 = (t7 + 0U);
    *((int *)t9) = 4;
    t9 = (t7 + 4U);
    *((int *)t9) = 0;
    t9 = (t7 + 8U);
    *((int *)t9) = -1;
    t16 = (0 - 4);
    t17 = (t16 * -1);
    t17 = (t17 + 1);
    t9 = (t7 + 12U);
    *((unsigned int *)t9) = t17;
    t18 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t1, t13);
    t19 = (t18 - 31);
    t17 = (t19 * -1);
    xsi_vhdl_check_range_of_index(31, 0, -1, t18);
    t20 = (1U * t17);
    t9 = (t0 + 1032U);
    t14 = *((char **)t9);
    t21 = (9 - 9);
    t23 = (t21 * 1U);
    t24 = (0 + t23);
    t9 = (t14 + t24);
    t15 = (t26 + 0U);
    t22 = (t15 + 0U);
    *((int *)t22) = 9;
    t22 = (t15 + 4U);
    *((int *)t22) = 5;
    t22 = (t15 + 8U);
    *((int *)t22) = -1;
    t29 = (5 - 9);
    t25 = (t29 * -1);
    t25 = (t25 + 1);
    t22 = (t15 + 12U);
    *((unsigned int *)t22) = t25;
    t31 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t9, t26);
    t32 = (t31 - 31);
    t25 = (t32 * -1);
    xsi_vhdl_check_range_of_index(31, 0, -1, t31);
    t30 = (32U * t25);
    t33 = (0 + t30);
    t34 = (t33 + t20);
    t22 = (t3 + t34);
    t2 = *((unsigned char *)t22);
    t27 = (t0 + 3936);
    t28 = (t27 + 56U);
    t35 = *((char **)t28);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    *((unsigned char *)t37) = t2;
    xsi_driver_first_trans_fast_port(t27);
    xsi_set_current_line(93, ng0);
    t1 = (t0 + 2312U);
    t3 = *((char **)t1);
    t1 = (t0 + 1832U);
    t4 = *((char **)t1);
    t10 = (4 - 4);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t4 + t12);
    t7 = (t13 + 0U);
    t9 = (t7 + 0U);
    *((int *)t9) = 4;
    t9 = (t7 + 4U);
    *((int *)t9) = 0;
    t9 = (t7 + 8U);
    *((int *)t9) = -1;
    t16 = (0 - 4);
    t17 = (t16 * -1);
    t17 = (t17 + 1);
    t9 = (t7 + 12U);
    *((unsigned int *)t9) = t17;
    t18 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t1, t13);
    t19 = (t18 - 31);
    t17 = (t19 * -1);
    xsi_vhdl_check_range_of_index(31, 0, -1, t18);
    t20 = (1U * t17);
    t9 = (t0 + 1672U);
    t14 = *((char **)t9);
    t21 = (4 - 4);
    t23 = (t21 * 1U);
    t24 = (0 + t23);
    t9 = (t14 + t24);
    t15 = (t26 + 0U);
    t22 = (t15 + 0U);
    *((int *)t22) = 4;
    t22 = (t15 + 4U);
    *((int *)t22) = 0;
    t22 = (t15 + 8U);
    *((int *)t22) = -1;
    t29 = (0 - 4);
    t25 = (t29 * -1);
    t25 = (t25 + 1);
    t22 = (t15 + 12U);
    *((unsigned int *)t22) = t25;
    t31 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t9, t26);
    t32 = (t31 - 31);
    t25 = (t32 * -1);
    xsi_vhdl_check_range_of_index(31, 0, -1, t31);
    t30 = (32U * t25);
    t33 = (0 + t30);
    t34 = (t33 + t20);
    t22 = (t3 + t34);
    t2 = *((unsigned char *)t22);
    t27 = (t0 + 4000);
    t28 = (t27 + 56U);
    t35 = *((char **)t28);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    *((unsigned char *)t37) = t2;
    xsi_driver_first_trans_fast_port(t27);
    goto LAB3;

LAB5:    xsi_set_current_line(90, ng0);
    t3 = (t0 + 1512U);
    t7 = *((char **)t3);
    t8 = *((unsigned char *)t7);
    t3 = (t0 + 1672U);
    t9 = *((char **)t3);
    t10 = (4 - 4);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t3 = (t9 + t12);
    t14 = (t13 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 4;
    t15 = (t14 + 4U);
    *((int *)t15) = 0;
    t15 = (t14 + 8U);
    *((int *)t15) = -1;
    t16 = (0 - 4);
    t17 = (t16 * -1);
    t17 = (t17 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t17;
    t18 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t3, t13);
    t19 = (t18 - 31);
    t17 = (t19 * -1);
    t20 = (32U * t17);
    t21 = (0U + t20);
    t15 = (t0 + 1832U);
    t22 = *((char **)t15);
    t23 = (4 - 4);
    t24 = (t23 * 1U);
    t25 = (0 + t24);
    t15 = (t22 + t25);
    t27 = (t26 + 0U);
    t28 = (t27 + 0U);
    *((int *)t28) = 4;
    t28 = (t27 + 4U);
    *((int *)t28) = 0;
    t28 = (t27 + 8U);
    *((int *)t28) = -1;
    t29 = (0 - 4);
    t30 = (t29 * -1);
    t30 = (t30 + 1);
    t28 = (t27 + 12U);
    *((unsigned int *)t28) = t30;
    t31 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t15, t26);
    t32 = (t31 - 31);
    t30 = (t32 * -1);
    t33 = (1 * t30);
    t34 = (t21 + t33);
    t28 = (t0 + 3872);
    t35 = (t28 + 56U);
    t36 = *((char **)t35);
    t37 = (t36 + 56U);
    t38 = *((char **)t37);
    *((unsigned char *)t38) = t8;
    xsi_driver_first_trans_delta(t28, t34, 1, 0LL);
    goto LAB6;

}


extern void work_a_2974294041_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2974294041_3212880686_p_0};
	xsi_register_didat("work_a_2974294041_3212880686", "isim/sch_sch_sch_tb_isim_beh.exe.sim/work/a_2974294041_3212880686.didat");
	xsi_register_executes(pe);
}
